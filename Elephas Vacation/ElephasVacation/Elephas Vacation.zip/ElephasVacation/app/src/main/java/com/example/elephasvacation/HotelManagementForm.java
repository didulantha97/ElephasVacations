package com.example.elephasvacation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HotelManagementForm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel_management_form);
    }
}
